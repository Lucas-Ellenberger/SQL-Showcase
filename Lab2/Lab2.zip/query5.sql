SELECT DISTINCT p.playTitle, t.theaterID
FROM Productions p, Theaters t
WHERE p.theaterID = t.theaterID
AND p.playTitle != ALL (SELECT p1.playTitle 
                        FROM Productions p1 
                        WHERE p1.theaterID != t.theaterID);
